"""Classical IAMB against the StablePFN discovery head and the axial certificate.

Every method returns a boundary set. The score is overlap with
parents ∪ children ∪ spouses. Parent, child, and spouse recall are coverage
of those true groups by the predicted set, not arrow accuracy.
"""

from __future__ import annotations

import numpy as np

from axialmb.infer import design_matrix, predict_scores
from axialmb.metrics import roles_from_labels
from axialmb.prior import generate_world

from .baselines.classical_mb import confirmed_boundary, iamb
from .baselines.stablepfn_mb import discovery_boundary, load_stablepfn
from .common import load_axial, print_table, score_target, summarize, write_json


def _axial_set(model, fusion, x, y, alpha, block, device, score_tau=None, cfg=None):
    """Axial boundary. ``alpha`` and ``block`` remain for call-site compatibility."""
    del alpha, block
    try:
        prob, _, _, stats = predict_scores(model, x, y, device)
    except RuntimeError as exc:
        if "out of memory" not in str(exc).lower() or not str(device).startswith("cuda"):
            raise
        import torch
        torch.cuda.empty_cache()
        model.to("cpu")
        prob, _, _, stats = predict_scores(model, x, y, "cpu")
    fused = fusion.score(design_matrix(prob, stats)) if fusion is not None else prob
    cont = 0.55 if score_tau is None else float(score_tau)
    extra = 0.65
    if cfg is not None:
        cont = float(cfg.get("continuous_tau", cfg.get("score_tau", cont)))
        extra = float(cfg.get("discrete_extra_tau", extra))
    return confirmed_boundary(x, y, fused, continuous_tau=cont, discrete_extra_tau=extra)


def run(args, run_dir):
    device = args.device
    model, fusion, cfg = load_axial(args.checkpoint, device)
    stable = None
    stable_note = "not requested"
    if args.stablepfn_checkpoint:
        try:
            stable = load_stablepfn(args.stablepfn_checkpoint, device=device)
            stable_note = args.stablepfn_checkpoint
        except Exception as exc:
            stable_note = f"failed to load: {type(exc).__name__}: {exc}"
    elif not args.stablepfn_checkpoint:
        stable_note = "pass --stablepfn-checkpoint to score the StablePFN discovery head"

    n_worlds = 2 if args.quick else 8
    p = 10 if args.quick else 18
    n = 250 if args.quick else 800
    want = 4 if args.quick else 6
    block = 20 if cfg is None else cfg.get("block", 20)
    score_tau = None if cfg is None else cfg.get("score_tau")
    rng = np.random.default_rng(args.seed)
    rows = {"iamb": [], "axialmb": [], "stablepfn_discovery": []}
    details = []
    for i in range(n_worlds):
        world = generate_world(rng, p=p, n=n, target_mb=want)
        roles = roles_from_labels(world["member"], world["type"], world["orient"])
        iamb_set = iamb(world["X"], world["y"], alpha=args.alpha)
        record = {
            "world": i,
            "family": world["family"],
            "mech": world["mech"],
            "iamb": sorted(iamb_set),
            "truth_boundary": sorted(roles["boundary"]),
        }
        rows["iamb"].append(score_target(iamb_set, roles))
        if model is not None:
            axial_set = _axial_set(
                model, fusion, world["X"], world["y"], args.fdr, block, device, score_tau, cfg,
            )
            rows["axialmb"].append(score_target(axial_set, roles))
            record["axialmb"] = axial_set
        if stable is not None:
            try:
                sp_set, _scores = discovery_boundary(stable, world["X"], world["y"], device=device)
                rows["stablepfn_discovery"].append(score_target(sp_set, roles))
                record["stablepfn_discovery"] = sp_set
            except Exception as exc:
                record["stablepfn_discovery_error"] = f"{type(exc).__name__}: {exc}"
        details.append(record)
        print(f"  world {i + 1}/{n_worlds} {world['family']} {world['mech']} |MB|={len(roles['boundary'])}")

    summary = {k: v for k, v in summarize(rows).items() if rows[k]}
    if model is None:
        summary["axialmb"] = {"status": "skipped", "reason": f"no checkpoint at {args.checkpoint}"}
    if stable is None:
        summary["stablepfn_discovery"] = {"status": "skipped", "reason": stable_note}
    payload = {
        "task": "classical_mb_vs_discovery",
        "what_is_measured": "boundary overlap (parents, children, spouses). Orientation is not scored.",
        "alpha_iamb": args.alpha,
        "fdr_axial": args.fdr,
        "n_worlds": n_worlds,
        "p": p,
        "n": n,
        "checkpoint": None if model is None else args.checkpoint,
        "stablepfn": stable_note,
        "summary": summary,
        "worlds": details,
    }
    print_table("Markov boundary: IAMB vs discovery heads", summary)
    write_json(run_dir / "mb_classical.json", payload)
    return payload
