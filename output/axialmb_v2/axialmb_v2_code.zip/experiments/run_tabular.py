"""Tabular benchmarks and the real Sachs observational table.

Benchmarks are forward samples from the bnlearn networks whose Markov
boundaries are known exactly (survey, asia, sachs, child). The real baseline
is the Sachs CD3/CD28 log-expression table, scored against that same consensus
boundary. Discrete classical tests see the integer categories. The axial
model and the StablePFN discovery head see the z-scored matrix.
"""

from __future__ import annotations

import numpy as np

from .baselines.causal import avici_boundaries, ges_boundaries, pc_boundaries, try_method
from .baselines.classical_mb import iamb
from .baselines.stablepfn_mb import discovery_boundary, load_stablepfn
from .common import load_axial, print_table, score_target, summarize, write_json
from .datasets import load_sachs_real, sample_bnlearn
from .run_mb import _axial_set


def _names_from_local(local, names, target):
    keep = [j for j in range(len(names)) if j != target]
    return {names[keep[j]] for j in local}


def _evaluate(table, model, fusion, stable, args, device, block, discrete, score_tau=None, cfg=None):
    names = table["names"]
    neural = table["standard"]
    classical = table["codes"] if discrete else np.asarray(table["standard"], dtype=np.float64)
    rows = {m: [] for m in ("iamb", "pc", "ges", "avici", "axialmb", "stablepfn_discovery")}
    errors = []
    pc_b, pc_info = try_method(lambda: pc_boundaries(classical, names, alpha=args.alpha, max_cond=3))
    ges_b, ges_info = try_method(lambda: ges_boundaries(classical, names))
    avici_matrix = neural if not discrete else table["standard"]
    avici_b, avici_info = try_method(lambda: avici_boundaries(avici_matrix, names))
    graph = {"pc": (pc_b, pc_info), "ges": (ges_b, ges_info), "avici": (avici_b, avici_info)}

    for t, name in enumerate(names):
        roles = table["roles"][name]
        if not roles["boundary"]:
            continue
        for method, (boundaries, _info) in graph.items():
            if boundaries is not None and name in boundaries:
                rows[method].append(score_target(boundaries[name], roles))
        pred = iamb(np.delete(classical, t, axis=1), classical[:, t], alpha=args.alpha)
        rows["iamb"].append(score_target(_names_from_local(pred, names, t), roles))
        reduced = np.delete(neural, t, axis=1)
        y = neural[:, t]
        if model is not None:
            local = _axial_set(model, fusion, reduced, y, args.fdr, block, device, score_tau, cfg)
            rows["axialmb"].append(score_target(_names_from_local(local, names, t), roles))
        if stable is not None:
            try:
                local, _scores = discovery_boundary(stable, reduced, y, device=device)
                rows["stablepfn_discovery"].append(
                    score_target(_names_from_local(local, names, t), roles)
                )
            except Exception as exc:
                errors.append({"target": name, "error": f"{type(exc).__name__}: {exc}"})
    summary = {k: v for k, v in summarize(rows).items() if rows[k]}
    if model is None:
        summary["axialmb"] = {"status": "skipped", "reason": f"no checkpoint at {args.checkpoint}"}
    if stable is None:
        summary["stablepfn_discovery"] = {"status": "skipped", "reason": "no StablePFN checkpoint"}
    for method, (_b, info) in graph.items():
        if method not in summary:
            summary[method] = info
    return {"summary": summary, "notes": {m: info for m, (_b, info) in graph.items()}, "errors": errors}


def run(args, run_dir):
    device = args.device
    model, fusion, cfg = load_axial(args.checkpoint, device)
    block = 20 if cfg is None else cfg.get("block", 20)
    score_tau = None if cfg is None else cfg.get("score_tau")
    stable = None
    if args.stablepfn_checkpoint:
        try:
            stable = load_stablepfn(args.stablepfn_checkpoint, device=device)
        except Exception as exc:
            print(f"StablePFN checkpoint failed: {exc}")
    names = ["survey"] if args.quick else ["survey", "asia", "sachs", "child"]
    # Discrete BIC on survey returns an empty graph below roughly 2000 rows,
    # so the quick check uses the same sample size as the full tabular run.
    n_samples = 2000
    datasets = {}
    for name in names:
        print(f"  benchmark {name} n={n_samples}")
        table = sample_bnlearn(name, n_samples, seed=args.seed)
        datasets[name] = _evaluate(
            table, model, fusion, stable, args, device, block, discrete=True, score_tau=score_tau, cfg=cfg,
        )
        print_table(f"bnlearn {name}", datasets[name]["summary"])
    print("  real baseline: Sachs CD3/CD28 observational")
    real = load_sachs_real()
    datasets[real["name"]] = _evaluate(
        real, model, fusion, stable, args, device, block, discrete=False, score_tau=score_tau, cfg=cfg,
    )
    datasets[real["name"]]["note"] = real["note"]
    print_table("Sachs observational (consensus boundary)", datasets[real["name"]]["summary"])
    payload = {
        "task": "tabular_benchmark_and_real",
        "what_is_measured": "Boundary overlap on bnlearn samples and on the real Sachs table.",
        "alpha": args.alpha,
        "fdr_axial": args.fdr,
        "datasets": datasets,
    }
    write_json(run_dir / "tabular.json", payload)
    return payload
