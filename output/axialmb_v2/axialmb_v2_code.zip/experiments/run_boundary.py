"""AVICI and classical causal discovery, scored on the Markov boundary.

PC and GES estimate a CPDAG. The reported set for each target is the
neighborhood of that target in the moral graph: parents, children, and
spouses. No orientation metric is computed.
"""

from __future__ import annotations

import numpy as np

from axialmb.metrics import roles_from_labels

from .baselines.causal import avici_boundaries, ges_boundaries, pc_boundaries, try_method
from .common import load_axial, print_table, score_target, summarize, write_json
from .datasets import sample_bnlearn
from .run_mb import _axial_set


def _shift_roles(roles):
    """Feature indices in X become column indices in ``[y, X]``."""
    return {key: {i + 1 for i in values} for key, values in roles.items()}


def _name_boundary(boundaries, names, target_name):
    if boundaries is None or target_name not in boundaries:
        return None
    return boundaries[target_name]


def run(args, run_dir):
    device = args.device
    model, fusion, cfg = load_axial(args.checkpoint, device)
    block = 20 if cfg is None else cfg.get("block", 20)
    score_tau = None if cfg is None else cfg.get("score_tau")
    n_worlds = 2 if args.quick else 6
    p = 8 if args.quick else 12
    n = 400 if args.quick else 1000
    want = 3 if args.quick else 4
    rng = np.random.default_rng(args.seed + 3)
    methods = ["pc", "ges", "avici", "axialmb"]
    rows = {m: [] for m in methods}
    details = []
    notes = {}

    for i in range(n_worlds):
        from axialmb.prior import generate_world
        world = generate_world(rng, p=p, n=n, target_mb=want, family="collider_hub")
        roles = _shift_roles(roles_from_labels(world["member"], world["type"], world["orient"]))
        data = np.column_stack([world["y"], world["X"]])
        names = [f"v{j}" for j in range(data.shape[1])]
        record = {"world": i, "family": world["family"], "mech": world["mech"]}
        for method, fn in (
            ("pc", lambda: pc_boundaries(data, names, alpha=args.alpha)),
            ("ges", lambda: ges_boundaries(data, names)),
            ("avici", lambda: avici_boundaries(data, names)),
        ):
            boundaries, info = try_method(fn)
            notes[method] = {k: v for k, v in info.items() if k != "status"} | {"status": info.get("status")}
            pred = _name_boundary(boundaries, names, names[0])
            if pred is None:
                record[method] = info
                continue
            pred_idx = {int(name[1:]) for name in pred}
            rows[method].append(score_target(pred_idx, roles))
            record[method] = sorted(pred_idx)
        if model is not None:
            axial = _axial_set(model, fusion, world["X"], world["y"], args.fdr, block, device, score_tau, cfg)
            # axial indices live in X; shift them onto the stacked matrix
            rows["axialmb"].append(score_target({j + 1 for j in axial}, roles))
            record["axialmb"] = axial
        details.append(record)
        print(f"  synthetic {i + 1}/{n_worlds} {world['mech']}")

    # One small real network so the boundary comparison is not only synthetic.
    bench_name = "survey" if args.quick else "asia"
    bench_n = 2000
    table = sample_bnlearn(bench_name, bench_n, seed=args.seed)
    bench_rows = {m: [] for m in methods}
    for t, name in enumerate(table["names"]):
        roles = table["roles"][name]
        if not roles["boundary"]:
            continue
        if model is not None:
            reduced = np.delete(table["standard"], t, axis=1)
            y = table["standard"][:, t]
            local = _axial_set(model, fusion, reduced, y, args.fdr, block, device, score_tau, cfg)
            keep = [j for j in range(table["standard"].shape[1]) if j != t]
            pred_names = {table["names"][keep[j]] for j in local}
            bench_rows["axialmb"].append(score_target(pred_names, roles))
    # Graph methods see the whole discrete table once.
    codes = table["codes"]
    for method, fn in (
        ("pc", lambda: pc_boundaries(codes, table["names"], alpha=args.alpha, max_cond=3)),
        ("ges", lambda: ges_boundaries(codes, table["names"])),
        ("avici", lambda: avici_boundaries(table["standard"], table["names"])),
    ):
        boundaries, info = try_method(fn)
        notes[f"{bench_name}_{method}"] = info
        if boundaries is None:
            continue
        for name in table["names"]:
            roles = table["roles"][name]
            if not roles["boundary"] or name not in boundaries:
                continue
            bench_rows[method].append(score_target(boundaries[name], roles))

    summary = {k: v for k, v in summarize(rows).items() if rows[k]}
    bench_summary = {k: v for k, v in summarize(bench_rows).items() if bench_rows[k]}
    if model is None:
        summary["axialmb"] = {"status": "skipped", "reason": f"no checkpoint at {args.checkpoint}"}
        bench_summary["axialmb"] = summary["axialmb"]
    for method in ("pc", "ges", "avici"):
        if method not in summary:
            summary[method] = notes.get(method, {"status": "skipped"})
        if method not in bench_summary:
            bench_summary[method] = notes.get(f"{bench_name}_{method}", {"status": "skipped"})

    payload = {
        "task": "causal_discovery_boundary",
        "what_is_measured": (
            "Moral-graph neighborhood of each target (parents, children, spouses). "
            "Orientation accuracy is not computed."
        ),
        "alpha": args.alpha,
        "fdr_axial": args.fdr,
        "synthetic_summary": summary,
        "benchmark": bench_name,
        "benchmark_summary": bench_summary,
        "notes": notes,
        "worlds": details,
    }
    print_table("Synthetic boundary recovery", summary)
    print_table(f"bnlearn {bench_name} boundary recovery", bench_summary)
    write_json(run_dir / "boundary.json", payload)
    return payload
