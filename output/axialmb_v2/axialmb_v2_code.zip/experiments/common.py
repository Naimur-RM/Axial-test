"""Shared loading, device, and result writing for the four evaluations."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

from axialmb.metrics import aggregate, boundary_scores
from axialmb.train import load_checkpoint

ROOT = Path(__file__).resolve().parents[1]


def device_of(name: str) -> str:
    if name:
        return name
    return "cuda" if torch.cuda.is_available() else "cpu"


def load_axial(path, device):
    path = Path(path)
    if not path.is_file():
        return None, None, None
    model, fusion, cfg = load_checkpoint(path, device=device)
    return model, fusion, cfg


def new_run_dir(root: str, name: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = Path(root) / name / stamp
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, payload: dict):
    path.write_text(json.dumps(payload, indent=2, default=_json_default), encoding="utf-8")
    print(f"saved {path}")


def _json_default(obj):
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, set):
        return sorted(obj)
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(type(obj))


def score_target(predicted, roles) -> dict:
    return boundary_scores(predicted, roles["parents"], roles["children"], roles["spouses"])


def summarize(rows_by_method: dict) -> dict:
    return {name: aggregate(rows) for name, rows in rows_by_method.items()}


def print_table(title: str, summary: dict):
    cols = ["precision", "recall", "f1", "fdr", "parent_recall", "child_recall", "spouse_recall"]
    print(f"\n{title}")
    header = f"{'method':<22}" + "".join(f"{c:>14}" for c in cols)
    print(header)
    print("-" * len(header))
    for name, stats in summary.items():
        if not isinstance(stats, dict) or "n" not in stats:
            print(f"{name:<22} {stats}")
            continue
        cells = []
        for col in cols:
            value = stats.get(col)
            cells.append(f"{value:14.3f}" if isinstance(value, float) else f"{'na':>14}")
        print(f"{name:<22}" + "".join(cells) + f"   n={stats.get('n')}")


def holdout_matrix(matrix, target):
    """Drop the target column. Return the reduced matrix and an index map old -> new."""
    keep = [j for j in range(matrix.shape[1]) if j != target]
    remap = {old: new for new, old in enumerate(keep)}
    return matrix[:, keep], remap
