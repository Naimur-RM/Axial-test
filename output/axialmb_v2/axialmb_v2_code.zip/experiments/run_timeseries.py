"""Lagged parent recovery against PC1, the first stage of PCMCI.

Synthetic linear and nonlinear VARs have a known parent set. The real series
is Box–Jenkins gas furnace. Two claims are scored there, because the book
fixes them and does not fix a unique autoregressive order:

- CO2 should depend on the gas rate at lags 3, 4 and 5.
- Past CO2 should not be selected as a parent of the gas input.

The axial model was trained on i.i.d. samples. Applying it to a lagged
design is zero-shot: every candidate is a past value, so the boundary it
returns is a parent set.
"""

from __future__ import annotations

import numpy as np

from axialmb.metrics import set_scores

from .baselines.pcmci_pc1 import pc1
from .common import load_axial, write_json
from .datasets import lagged_design, load_gas_furnace, parent_columns, var_process
from .run_mb import _axial_set


def _axial_links(model, fusion, series, lag, alpha, block, device, score_tau=None, cfg=None):
    d = series.shape[1]
    found = {}
    for target in range(d):
        design, y = lagged_design(series, target, lag)
        chosen = _axial_set(model, fusion, design, y, alpha, block, device, score_tau, cfg)
        found[target] = {(col // lag, col % lag + 1) for col in chosen}
    return found


def _mean_scores(found, truth):
    rows = []
    for target, true in truth.items():
        if not true:
            continue
        rows.append(set_scores(found.get(target, ()), true))
    if not rows:
        return {"n": 0}
    keys = rows[0].keys()
    return {k: float(np.mean([r[k] for r in rows])) for k in keys} | {"n": len(rows)}


def _gain(ours, base):
    if not ours or not base or "f1" not in ours or "f1" not in base:
        return None
    return {
        "f1_ours_minus_pc1": ours["f1"] - base["f1"],
        "recall_ours_minus_pc1": ours["recall"] - base["recall"],
        "precision_ours_minus_pc1": ours["precision"] - base["precision"],
    }


def _setting_block(model, fusion, series, truth, lag, alpha, fdr, block, device, score_tau=None, cfg=None):
    found_pc1, info = pc1(series, tau_max=lag, alpha=alpha)
    out = {"pc1": _mean_scores(found_pc1, truth), "pc1_info": info, "pc1_parents": _sets(found_pc1)}
    if model is None:
        out["axialmb"] = {"status": "skipped"}
        out["gain_vs_pc1"] = None
        return out
    found_axial = _axial_links(model, fusion, series, lag, fdr, block, device, score_tau, cfg)
    out["axialmb"] = _mean_scores(found_axial, truth)
    out["axialmb_parents"] = _sets(found_axial)
    out["gain_vs_pc1"] = _gain(out["axialmb"], out["pc1"])
    return out


def _sets(found):
    return {str(k): sorted(list(v)) for k, v in found.items()}


def _gas_claims(found):
    """found[0] parents of gas, found[1] parents of CO2. Links are (series, lag)."""
    from .datasets import GAS_FURNACE_FORBIDDEN, GAS_FURNACE_INPUT_LAGS
    co2 = set(found.get(1, ()))
    gas = set(found.get(0, ()))
    delay = GAS_FURNACE_INPUT_LAGS
    return {
        "input_delay_recall": len(co2 & delay) / len(delay),
        "input_delay_hits": sorted(co2 & delay),
        "exogeneity_violations": sorted(gas & GAS_FURNACE_FORBIDDEN),
        "n_exogeneity_violations": len(gas & GAS_FURNACE_FORBIDDEN),
        "parents_of_gas": sorted(gas),
        "parents_of_co2": sorted(co2),
    }


def run(args, run_dir):
    device = args.device
    model, fusion, cfg = load_axial(args.checkpoint, device)
    block = 20 if cfg is None else cfg.get("block", 20)
    score_tau = None if cfg is None else cfg.get("score_tau")
    if args.quick:
        settings = [
            ("linear", dict(d=4, lag=2, n=500, nonlinear=False, density=0.25)),
            ("nonlinear", dict(d=4, lag=2, n=500, nonlinear=True, density=0.25)),
        ]
        trials = 1
    else:
        settings = [
            ("linear_sparse", dict(d=5, lag=2, n=2000, nonlinear=False, density=0.15)),
            ("nonlinear_sparse", dict(d=5, lag=2, n=2000, nonlinear=True, density=0.15)),
            ("linear_denser", dict(d=6, lag=2, n=2000, nonlinear=False, density=0.3)),
        ]
        trials = 3

    synthetic = {}
    for name, kw in settings:
        pc1_rows, axial_rows = [], []
        info = None
        for trial in range(trials):
            rng = np.random.default_rng(args.seed + trial)
            series, truth = var_process(rng=rng, **kw)
            block_result = _setting_block(
                model, fusion, series, truth, kw["lag"], args.alpha, args.fdr, block, device, score_tau, cfg,
            )
            info = block_result["pc1_info"]
            pc1_rows.append(block_result["pc1"])
            if "f1" in block_result.get("axialmb", {}):
                axial_rows.append(block_result["axialmb"])
            print(f"  {name} trial {trial + 1}/{trials} PC1 F1 {block_result['pc1'].get('f1', float('nan')):.3f}")
        pc1_mean = _average(pc1_rows)
        axial_mean = _average(axial_rows) if axial_rows else {"status": "skipped", "reason": f"no checkpoint at {args.checkpoint}"}
        synthetic[name] = {
            "pc1": pc1_mean,
            "axialmb": axial_mean,
            "gain_vs_pc1": _gain(axial_mean, pc1_mean),
            "pc1_info": info,
            "setting": kw,
        }

    gas = load_gas_furnace()
    gas_pc1, gas_info = pc1(gas["series"], tau_max=gas["tau_max"], alpha=args.alpha)
    gas_out = {
        "note": gas["note"],
        "pc1": _gas_claims(gas_pc1),
        "pc1_info": gas_info,
    }
    if model is not None:
        gas_axial = _axial_links(
            model, fusion, gas["series"], gas["tau_max"], args.fdr, block, device, score_tau, cfg,
        )
        gas_out["axialmb"] = _gas_claims(gas_axial)
        gas_out["where_axial_helps"] = _gas_help(gas_out["axialmb"], gas_out["pc1"])
    else:
        gas_out["axialmb"] = {"status": "skipped", "reason": f"no checkpoint at {args.checkpoint}"}

    payload = {
        "task": "timeseries_vs_pcmci_pc1",
        "what_is_measured": (
            "Lagged parent set. PC1 is the parent-screening stage of PCMCI, "
            "before the MCI contemporaneous tests. No orientation is scored."
        ),
        "synthetic": synthetic,
        "gas_furnace": gas_out,
    }
    _print_ts(synthetic, gas_out)
    write_json(run_dir / "timeseries.json", payload)
    return payload


def _average(rows):
    if not rows:
        return {}
    keys = [k for k in rows[0] if isinstance(rows[0][k], (int, float))]
    return {k: float(np.mean([r[k] for r in rows])) for k in keys} | {"n": len(rows)}


def _gas_help(ours, base):
    return {
        "input_delay_recall_ours_minus_pc1": ours["input_delay_recall"] - base["input_delay_recall"],
        "exogeneity_violations_ours_minus_pc1": (
            ours["n_exogeneity_violations"] - base["n_exogeneity_violations"]
        ),
    }


def _print_ts(synthetic, gas):
    print("\nTime series vs PCMCI-PC1 (positive F1 gain means the axial blanket beats PC1)")
    print(f"{'setting':<20} {'PC1 F1':>10} {'Axial F1':>10} {'F1 gain':>10} {'recall gain':>12}")
    for name, block in synthetic.items():
        pc1_f1 = block["pc1"].get("f1")
        ax_f1 = block["axialmb"].get("f1") if isinstance(block["axialmb"], dict) else None
        gain = block.get("gain_vs_pc1") or {}
        def fmt(v):
            return f"{v:10.3f}" if isinstance(v, float) else f"{'—':>10}"
        rec = gain.get("recall_ours_minus_pc1")
        rec_s = f"{rec:12.3f}" if isinstance(rec, float) else f"{'—':>12}"
        print(f"{name:<20} {fmt(pc1_f1)} {fmt(ax_f1)} {fmt(gain.get('f1_ours_minus_pc1'))} {rec_s}")
    print("\nGas furnace (real): delay-3/4/5 gas -> CO2 recall, and CO2 -> gas violations")
    for method in ("pc1", "axialmb"):
        block = gas.get(method, {})
        if "input_delay_recall" not in block:
            print(f"  {method}: {block.get('status', block)}")
            continue
        print(
            f"  {method}: delay recall {block['input_delay_recall']:.2f}, "
            f"exogeneity violations {block['n_exogeneity_violations']}"
        )
